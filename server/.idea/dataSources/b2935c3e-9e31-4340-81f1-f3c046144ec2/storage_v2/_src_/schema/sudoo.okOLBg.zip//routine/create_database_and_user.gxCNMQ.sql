create
    definer = root@localhost procedure create_database_and_user(IN db_name varchar(255), IN user_name varchar(255),
                                                                IN password varchar(255))
BEGIN
    SET @is_exists_database=(SELECT is_exists_database(`db_name`));
    IF NOT @is_exists_database THEN
        CALL create_database(`db_name`);
        CALL create_user_and_grant(`user_name`, `password`, `db_name`);
        FLUSH PRIVILEGES;
    END IF;
END;

