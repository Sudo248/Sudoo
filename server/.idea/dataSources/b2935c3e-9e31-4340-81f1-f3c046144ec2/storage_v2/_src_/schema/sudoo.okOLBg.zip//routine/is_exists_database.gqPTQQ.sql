create
    definer = root@localhost function is_exists_database(db_name varchar(255)) returns tinyint(1) deterministic
BEGIN
    DECLARE `db_count` INT DEFAULT 0;
    SELECT COUNT(*) INTO `db_count` FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = `db_name`;
    IF `db_count` > 0 THEN
        RETURN TRUE;
    ELSE
        RETURN FALSE;
    END IF;
END;

