create
    definer = root@localhost procedure create_user_and_grant(IN service_name varchar(255), IN password varchar(255),
                                                             IN db_name varchar(255))
BEGIN
    #CREATE USER
    SET @`user_host` = CONCAT('\"',`service_name`,'\"','@\'%\'');
    SET @`sql` := CONCAT('CREATE USER IF NOT EXISTS ', @`user_host`, ' IDENTIFIED BY \'', `password`,'\'');
    PREPARE `stmt` FROM @`sql`;
    EXECUTE `stmt`;

    #GRANT ALL PRIVILEGES FOR USER
    SET @`sql` := CONCAT('GRANT ALL PRIVILEGES ON \`', `db_name`, '\`.* TO ', @`user_host`);
    PREPARE `stmt` FROM @`sql`;
    EXECUTE `stmt`;
    DEALLOCATE PREPARE `stmt`;
END;

