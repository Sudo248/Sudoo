create
    definer = root@localhost procedure create_database(IN db_name varchar(255))
BEGIN
    #CREATE DATABASE
    SET @`sql` := CONCAT('CREATE DATABASE \`', `db_name`,'\`');
    PREPARE `stmt` FROM @`sql`;
    EXECUTE `stmt`;
    DEALLOCATE PREPARE `stmt`;
END;

